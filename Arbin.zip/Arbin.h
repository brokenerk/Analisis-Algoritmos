#include "Elem.h"

typedef struct NodoA
{
	Elem raiz;
	struct NodoA*izq;
	struct NodoA*der;
}*Arbin;

Arbin vacioA() {return NULL;}
Arbin consA(Elem r, Arbin i, Arbin d)
{
	Arbin t=(Arbin)malloc(sizeof(struct NodoA));
	t->raiz=r;
	t->izq=i;
	t->der=d;
	return t;
}

int esvacioA(Arbin a) {return a==NULL;}
Elem raiz(Arbin a) {return a->raiz;}
Arbin izquierdo(Arbin a) {return a->izq;}
Arbin derecho(Arbin a) {return a->der;}

void ImpPreOrd (Arbin a)
{
	if (!esvacioA(a))
	{
		ImpElem(raiz(a));
		ImpPreOrd(izquierdo(a));
		ImpPreOrd(derecho(a));
	}
}

void ImpInOrd (Arbin a)
{
	if (!esvacioA(a))
	{
		ImpInOrd(izquierdo(a));
		ImpElem(raiz(a));
		ImpInOrd(derecho(a));
	}
}

void ImpPostOrd (Arbin a)
{
	if (!esvacioA(a))
	{
		ImpPostOrd(izquierdo(a));
		ImpPostOrd(derecho(a));
		ImpElem(raiz(a));
	}
}

int NumElemA (Arbin a)
{
	if (esvacioA(a))
		return 0;
	else
		return 1+NumElemA(izquierdo(a))+NumElemA(derecho(a));	
} 

int maximo (int a, int b)
{
	if (a>b)
		return a;
	else
		return b;
}

int altura (Arbin a)
{
	if (esvacioA(a))
		return 0;
	else
		return 1+maximo(altura(izquierdo(a)), altura(derecho(a)));
}

void ImpNivel(Arbin a, int n)
{
    if(!esvacio(a))
        if(n==1)
            ImpElem(raiz(a));
        else
		{
            ImpNivel(izquierdo(a),n-1); 
            ImpNivel(derecho(a),n-1);   
        }
    else 
        printf("[]");         
}
     
void ImpPorNivel(Arbin a)
{
    int i, n=altura(a);
    for(i=1;i<=n;i++)
	{
        ImpNivel(a,i);
        printf("\n");
    }     
}           


