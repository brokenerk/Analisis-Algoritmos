typedef int Elem;//Definicion del tipo abstracto Elem

void ImpElem(Elem e){printf("%d ", e);}//Imprimir Elementos de la lista
int IgualesElem(Elem e1, Elem e2){return e1==e2;}//Compara 2 elementos y devuelve un booleano
int EsMenor(Elem e1, Elem e2){return e1<e2;}//Si es menor, devuelve un booleano
int EsMayor(Elem e1, Elem e2){return e1>e2;}//Si es menor, devuelve un booleano




