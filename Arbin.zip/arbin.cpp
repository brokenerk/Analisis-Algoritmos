#include <stdio.h>
#include <stdlib.h>
#include "Arbin.h"

int main()
{
	Arbin a=consA(30,consA(20,consA(10,vacioA(),vacioA()),vacioA()),consA(50,consA(40, vacioA(),vacioA()),consA(60,vacioA(),vacioA())));
	ImpPreOrd(a);
	printf("\n");
	ImpInOrd(a);
	printf("\n");
	ImpPostOrd(a);
	
	printf("\n# de Elementos: %d", NumElemA(a));
	printf("\nLa altura es: %d", altura(a));
}
